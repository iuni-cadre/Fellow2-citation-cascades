#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from collections import namedtuple
import numpy as np

from pyspark.ml import Estimator, Model, Transformer, UnaryTransformer
from pyspark.ml.param import Param, Params, TypeConverters
from pyspark.ml.util import DefaultParamsReadable, DefaultParamsWritable
from pyspark.ml.wrapper import _java2py
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import DoubleType
from pyspark.testing.utils import ReusedPySparkTestCase as PySparkTestCase


def check_params(test_self, py_stage, check_params_exist=True):
    """
    Checks common requirements for Params.params:
      - set of params exist in Java and Python and are ordered by names
      - param parent has the same UID as the object's UID
      - default param value from Java matches value in Python
      - optionally check if all params from Java also exist in Python
    """
    py_stage_str = "%s %s" % (type(py_stage), py_stage)
    if not hasattr(py_stage, "_to_java"):
        return
    java_stage = py_stage._to_java()
    if java_stage is None:
        return
    test_self.assertEqual(py_stage.uid, java_stage.uid(), msg=py_stage_str)
    if check_params_exist:
        param_names = [p.name for p in py_stage.params]
        java_params = list(java_stage.params())
        java_param_names = [jp.name() for jp in java_params]
        test_self.assertEqual(
            param_names, sorted(java_param_names),
            "Param list in Python does not match Java for %s:\nJava = %s\nPython = %s"
            % (py_stage_str, java_param_names, param_names))
    for p in py_stage.params:
        test_self.assertEqual(p.parent, py_stage.uid)
        java_param = java_stage.getParam(p.name)
        py_has_default = py_stage.hasDefault(p)
        java_has_default = java_stage.hasDefault(java_param)
        test_self.assertEqual(py_has_default, java_has_default,
                              "Default value mismatch of param %s for Params %s"
                              % (p.name, str(py_stage)))
        if py_has_default:
            if p.name == "seed":
                continue  # Random seeds between Spark and PySpark are different
            java_default = _java2py(test_self.sc,
                                    java_stage.clear(java_param).getOrDefault(java_param))
            py_stage._clear(p)
            py_default = py_stage.getOrDefault(p)
            # equality test for NaN is always False
            if isinstance(java_default, float) and np.isnan(java_default):
                java_default = "NaN"
                py_default = "NaN" if np.isnan(py_default) else "not NaN"
            test_self.assertEqual(
                java_default, py_default,
                "Java default %s != python default %s of param %s for Params %s"
                % (str(java_default), str(py_default), p.name, str(py_stage)))


class SparkSessionTestCase(PySparkTestCase):
    @classmethod
    def setUpClass(cls):
        PySparkTestCase.setUpClass()
        cls.spark = SparkSession(cls.sc)

    @classmethod
    def tearDownClass(cls):
        PySparkTestCase.tearDownClass()
        cls.spark.stop()


class MockDataset(DataFrame):

    def __init__(self):
        self.index = 0


class HasFake(Params):

    def __init__(self):
        super(HasFake, self).__init__()
        self.fake = Param(self, "fake", "fake param")

    def getFake(self):
        return self.getOrDefault(self.fake)


class MockTransformer(Transformer, HasFake):

    def __init__(self):
        super(MockTransformer, self).__init__()
        self.dataset_index = None

    def _transform(self, dataset):
        self.dataset_index = dataset.index
        dataset.index += 1
        return dataset


class MockUnaryTransformer(UnaryTransformer, DefaultParamsReadable, DefaultParamsWritable):

    shift = Param(Params._dummy(), "shift", "The amount by which to shift " +
                  "data in a DataFrame",
                  typeConverter=TypeConverters.toFloat)

    def __init__(self, shiftVal=1):
        super(MockUnaryTransformer, self).__init__()
        self._setDefault(shift=1)
        self._set(shift=shiftVal)

    def getShift(self):
        return self.getOrDefault(self.shift)

    def setShift(self, shift):
        self._set(shift=shift)

    def createTransformFunc(self):
        shiftVal = self.getShift()
        return lambda x: x + shiftVal

    def outputDataType(self):
        return DoubleType()

    def validateInputType(self, inputType):
        if inputType != DoubleType():
            raise TypeError("Bad input type: {}. ".format(inputType) +
                            "Requires Double.")


class MockEstimator(Estimator, HasFake):

    def __init__(self):
        super(MockEstimator, self).__init__()
        self.dataset_index = None

    def _fit(self, dataset):
        self.dataset_index = dataset.index
        model = MockModel()
        self._copyValues(model)
        return model


class MockModel(MockTransformer, Model, HasFake):
    pass


_mlflow_run_info = namedtuple('MLflowRun', ['run_uuid', 'params', 'metrics', 'tags'])
_active_run_stack = []
_run_history = []


class ActiveRun:
    """
    Wrapper class to enable ``with`` syntax like a contextmanager
    """
    def __init__(self):
        global _run_history
        self.run_id = len(_run_history)
        mlflow_run = _mlflow_run_info(run_uuid=self.run_id,
                                      params={},
                                      metrics={},
                                      tags={})
        _run_history.append(mlflow_run)
        self.info = _run_history[-1]

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        global _active_run_stack
        if len(_active_run_stack) > 0:
            _active_run_stack.pop()


class MockMLflow:
    """
    Mock class for MLflow fluent/stateful API
    """

    @staticmethod
    def start_run(nested=False):
        global _active_run_stack
        _active_run_stack.append(ActiveRun())
        return _active_run_stack[-1]

    @staticmethod
    def active_run():
        """Get the currently active ``Run``, or None if no such run exists."""
        global _active_run_stack
        return _active_run_stack[-1] if len(_active_run_stack) > 0 else None

    @staticmethod
    def _get_or_start_run():
        global _active_run_stack
        if len(_active_run_stack) == 0:
            MockMLflow.start_run()
        return _active_run_stack[-1]

    @staticmethod
    def log_param(name, value):
        global _run_history
        active_run = MockMLflow._get_or_start_run()
        run_info = _run_history[active_run.run_id]
        run_info.params[name] = value

    @staticmethod
    def log_metric(name, value):
        global _run_history
        active_run = MockMLflow._get_or_start_run()
        run_info = _run_history[active_run.run_id]
        run_info.metrics[name] = value

    @staticmethod
    def set_tag(name, value):
        global _run_history
        active_run = MockMLflow._get_or_start_run()
        run_info = _run_history[active_run.run_id]
        run_info.tags[name] = value


class MockMLflowUtil:
    """
    Helper class to check the logging by the mock MockMLflow and MockMlflowClient class
    """
    @staticmethod
    def _get_experiment_id():
        return 0

    @staticmethod
    def cleanup_tests():
        global _active_run_stack
        global _run_history
        _active_run_stack = []
        _run_history = []

    @staticmethod
    def get_num_params():
        global _run_history
        num_params = 0
        for run in _run_history:
            num_params = num_params + len(run.params)
        return num_params

    @staticmethod
    def get_num_params_for_run(run_uuid):
        global _run_history
        return len(_run_history[run_uuid].params)

    @staticmethod
    def get_num_metrics():
        global _run_history
        num_metrics = 0
        for run in _run_history:
            num_metrics = num_metrics + len(run.metrics)
        return num_metrics

    @staticmethod
    def get_num_tags():
        global _run_history
        num_tag = 0
        for run in _run_history:
            num_tag = num_tag + len(run.tags)
        return num_tag

    @staticmethod
    def get_num_runs():
        global _run_history
        return len(_run_history)

    @staticmethod
    def get_param(run_uuid, name):
        global _run_history
        if name in _run_history[run_uuid].params:
            return _run_history[run_uuid].params[name]
        else:
            return None

    @staticmethod
    def get_metric(run_uuid, name):
        global _run_history
        if name in _run_history[run_uuid].metrics:
            return _run_history[run_uuid].metrics[name]
        else:
            return None

    @staticmethod
    def get_tag(run_uuid, name):
        global _run_history
        if name in _run_history[run_uuid].tags:
            return _run_history[run_uuid].tags[name]
        else:
            return None


class MockMlflowClient:
    """
    Mock for MLflow client interface
    """
    @staticmethod
    def create_run(experiment_id, parent_run_id=None):
        active_run = ActiveRun()
        return active_run

    @staticmethod
    def log_param(run_uuid, name, value):
        global _run_history
        run_info = _run_history[run_uuid]
        run_info.params[name] = value

    @staticmethod
    def log_metric(run_uuid, name, value):
        global _run_history
        run_info = _run_history[run_uuid]
        run_info.metrics[name] = value

    @staticmethod
    def set_tag(run_uuid, name, value):
        global _run_history
        run_info = _run_history[run_uuid]
        run_info.tags[name] = value
