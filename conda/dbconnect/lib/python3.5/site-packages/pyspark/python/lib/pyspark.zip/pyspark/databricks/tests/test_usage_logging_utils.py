#
# Copyright (C) 2019 Databricks, Inc.
#
# Portions of this software incorporate or are derived from software contained within Apache Spark,
# and this modified software differs from the Apache Spark software provided under the Apache
# License, Version 2.0, a copy of which you may obtain at
# http://www.apache.org/licenses/LICENSE-2.0
#

import unittest

from pyspark.databricks.testing.utils import UsageLoggingTestCase


class PythonUsageLoggingTest(UsageLoggingTestCase):
    """
    Test suite for Python wrapper for Databricks usage logging.
    """

    def test_basic_usage_logging(self):
        logger = self._usage_logging

        def function_with_logging():
            logger.recordEvent(
                logger.metricDefinitions().EVENT_ML_ALGORITHM(),
                {
                    logger.tagDefinitions().TAG_ML_RUN_UUID(): 'fakeTagEntry'
                },
                "my big blob"
            )
        usage_records = self.track_usage(function_with_logging)
        self.assertEqual(len(usage_records), 1,
                         "Expected 1 usage record but found {n}.".format(n=len(usage_records)))
        self.assert_tag(usage_records[0], logger.tagDefinitions().TAG_ML_RUN_UUID(),
                        'fakeTagEntry')


if __name__ == "__main__":
    from pyspark.databricks.tests.test_usage_logging_utils import *
    try:
        import xmlrunner
        unittest.main(testRunner=xmlrunner.XMLTestRunner(output='target/test-reports'), verbosity=2)
    except ImportError:
        unittest.main(verbosity=2)
