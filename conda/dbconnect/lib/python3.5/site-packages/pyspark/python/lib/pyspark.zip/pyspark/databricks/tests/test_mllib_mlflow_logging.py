# Copyright (C) 2018 Databricks, Inc.
#
# Portions of this software incorporate or are derived from software contained within Apache Spark,
# License, Version 2.0, a copy of which you may obtain at
# http://www.apache.org/licenses/LICENSE-2.0
#

from collections import namedtuple
import concurrent.futures
import numpy as np
import warnings
import unittest

from pyspark.databricks.testing.utils import UsageLoggingTestCase
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.ml.linalg import Vectors
from pyspark.ml.tuning import CrossValidator, TrainValidationSplit, ParamGridBuilder
from pyspark.ml import util
from pyspark.ml.util import _MLflowInstrumentation, _AsynchronousTaskQueue, _MLflowUsageLogger
from pyspark.testing.mlutils import MockMLflow, MockMLflowUtil, MockMlflowClient

# We have tests to make sure certain warning messages are printed. Setting the
# filter to "always" so that no warning messages would be suppressed.
warnings.simplefilter('always')


def wait_for_mlflow():
    """
    Wait for mlflow logging
    """
    concurrent.futures.wait(_MLflowInstrumentation.async_task_queue.futures)


mocked_mlflow = MockMLflow()
mlflow_util = MockMLflowUtil
run_info_size = namedtuple('MLflowRun', ['num_params', 'num_metrics', 'num_tags', 'num_runs'])


class MLlibMLflowLoggingTests(UsageLoggingTestCase):

    def setUp(self):
        super(MLlibMLflowLoggingTests, self).setUp()
        util._mlflow = mocked_mlflow
        util._MlflowClient = MockMlflowClient
        util._get_experiment_id = mlflow_util._get_experiment_id
        _MLflowInstrumentation.mlflow_client = None

    def tearDown(self):
        mlflow_util.cleanup_tests()
        _MLflowInstrumentation.usage_logger = None
        super(MLlibMLflowLoggingTests, self).tearDown()

    def is_edge_mode_enabled(self):
        """
        Check whether edge mode is enabled
        """
        edgeModeEnabled = self.spark._jvm \
            .__getattr__('com.databricks.spark.DatabricksEdgeConfigs$') \
            .__getattr__('MODULE$') \
            .edgeModeEnabled()
        return edgeModeEnabled

    def assert_num_logs(self, num_logs, expected_num):
        """
        Assert that the number of records equals to expected_num.
        """
        self.assertEqual(num_logs, expected_num,
                         "Expected {e} usage record but found {n}."
                         .format(n=num_logs, e=expected_num))

    def check_run_info_size(self, expected_size):
        # Check number of mlflow.log_param calls
        num_params = mlflow_util.get_num_params()
        self.assertEqual(num_params,
                         expected_size.num_params,
                         "Wrong number of params logged in MLflow: Expected {e} but got {r}."
                         .format(e=expected_size.num_params, r=num_params))
        # Check number of mlflow.log_metric calls
        num_metrics = mlflow_util.get_num_metrics()
        self.assertEqual(num_metrics,
                         expected_size.num_metrics,
                         "Wrong number of metrics logged in MLflow: Expected {e} but got {r}."
                         .format(e=expected_size.num_metrics, r=num_metrics))
        # Check number of mlflow.set_tags calls
        num_tags = mlflow_util.get_num_tags()
        self.assertEqual(num_tags,
                         expected_size.num_tags,
                         "Wrong number of tags logged in MLflow: Expected {e} but got {r}."
                         .format(e=expected_size.num_tags, r=num_tags))
        num_runs = mlflow_util.get_num_runs()
        self.assertEqual(num_runs,
                         expected_size.num_runs,
                         "Wrong number of mlflow runs: Expected {e} but got {r}."
                         .format(e=expected_size.num_runs, r=num_runs))

    def check_run_info(self, run_uuid, expected_params, expected_metrics, expected_tags):
        # Check mlflow.log_param calls
        for param in expected_params:
            log_value = mlflow_util.get_param(run_uuid, param)
            self.assertEqual(log_value,
                             expected_params[param],
                             "Wrong value of param {n}: Expected {e} but got {r}."
                             .format(n=param, e=expected_params[param], r=log_value))

        # Check mlflow.log_metric calls
        for metric in expected_metrics:
            log_value = mlflow_util.get_metric(run_uuid, metric)
            self.assertEqual(log_value,
                             expected_metrics[metric],
                             "Wrong value of metric {n}: Expected {e} but got {r}."
                             .format(n=metric, e=expected_metrics[metric], r=log_value))
        # Check mlflow.set_tag calls
        for tag in expected_tags:
            log_value = mlflow_util.get_tag(run_uuid, tag)
            self.assertEqual(log_value,
                             expected_tags[tag],
                             "Wrong value of tag {n}: Expected {e} but got {r}."
                             .format(n=tag, e=expected_tags[tag], r=log_value))

    def test_log_single_run(self):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        lr = LogisticRegression()
        grid = ParamGridBuilder().addGrid(lr.maxIter, [0]).build()
        param_to_name = {lr.maxIter: lr.maxIter.name}
        metric_names = ["test1", "test2"]
        metrics = np.array([1.0, 2.0])

        mlflow_logger = _MLflowInstrumentation()
        _MLflowInstrumentation.mlflow_client = MockMlflowClient()

        with mocked_mlflow.start_run(nested=True) as active_run:
            run_uuid = active_run.info.run_uuid
            mlflow_logger._log_single_run(run_uuid, lr, grid[0], param_to_name,
                                          metric_names, metrics)
        wait_for_mlflow()

        expected_size = run_info_size(num_params=3, num_metrics=2, num_tags=1, num_runs=1)
        self.check_run_info_size(expected_size)

        expected_params = {"mlModelClass": type(lr).__name__,
                           "mlEstimatorUid": lr.uid,
                           lr.maxIter.name: 0}
        expected_metrics = {"test1": 1.0, "test2": 2.0}
        expected_tags = {"runSource": "mllibAutoTracking"}
        self.check_run_info(0, expected_params, expected_metrics, expected_tags)

    def test_log_tuning_runs(self):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        lr = LogisticRegression()
        grid = ParamGridBuilder().addGrid(lr.maxIter, [0, 1]).build()
        metric_names = ["test1", "test2"]
        metrics = np.array([[1.0, 2.0], [3.0, 4.0]])

        mlflow_logger = _MLflowInstrumentation()
        _MLflowInstrumentation.mlflow_client = MockMlflowClient()
        with mocked_mlflow.start_run(nested=True) as active_run:
            run_uuid = active_run.info.run_uuid
            mlflow_logger._log_tuning_runs(run_uuid, lr, grid, metric_names, metrics)
        wait_for_mlflow()

        expected_size = run_info_size(num_params=6, num_metrics=4, num_tags=2, num_runs=3)
        self.check_run_info_size(expected_size)

    def test_log_crossvalidator(self):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        lr = LogisticRegression()
        grid = ParamGridBuilder().addGrid(lr.maxIter, [0, 1]).build()
        evaluator = MulticlassClassificationEvaluator(metricName="accuracy")
        cv = CrossValidator(estimator=lr, estimatorParamMaps=grid, evaluator=evaluator, numFolds=4)
        metrics = np.array([[1.0, 2.0], [1.0, 2.0], [1.0, 4.0], [1.0, 4.0]])

        mlflow_logger = _MLflowInstrumentation()

        def run_log_crossvalidator():
            mlflow_logger.log_crossvalidator(cv, metrics)
            wait_for_mlflow()
        usage_records = self.track_usage(run_log_crossvalidator)

        expected_size = run_info_size(num_params=12, num_metrics=4, num_tags=3, num_runs=3)
        self.check_run_info_size(expected_size)

        expected_params = {'mlModelClass': "CrossValidator",
                           'mlEstimatorUid': cv.uid,
                           'estimator': type(lr).__name__,
                           'evaluator': type(evaluator).__name__,
                           'numFolds': 4,
                           'estimatorParamMapsLength': 2}
        self.check_run_info(0, expected_params, {}, {})

        # check we have logging the avg and std metrics
        expected_metrics = {"avg_accuracy": 1.0,
                            "std_accuracy": 0.0}
        self.check_run_info(1, {}, expected_metrics, {})

        expected_metrics = {"avg_accuracy": 3.0,
                            "std_accuracy": 1.0}
        self.check_run_info(2, {}, expected_metrics, {})

        # check Databricks usage logging
        self.assert_num_logs(len(usage_records), 1)
        self.assert_tag(usage_records[0],
                        self.tag_definitions().TAG_ML_UTIL_TYPE(),
                        'mllibAutoTracking')

    def test_log_trainvalidationsplit(self):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        lr = LogisticRegression()
        grid = ParamGridBuilder().addGrid(lr.maxIter, [0, 1]).build()
        evaluator = MulticlassClassificationEvaluator(metricName="accuracy")
        tvs = TrainValidationSplit(estimator=lr, estimatorParamMaps=grid, evaluator=evaluator)
        metrics = np.array([1.0, 2.0])

        mlflow_logger = _MLflowInstrumentation()

        def run_trainvalidationsplit():
            mlflow_logger.log_trainvalidationsplit(tvs, metrics)
            wait_for_mlflow()
        usage_records = self.track_usage(run_trainvalidationsplit)

        expected_size = run_info_size(num_params=11, num_metrics=2, num_tags=3, num_runs=3)
        self.check_run_info_size(expected_size)
        expected_params = {'mlModelClass': "TrainValidationSplit",
                           'mlEstimatorUid': tvs.uid,
                           'estimator': type(lr).__name__,
                           'evaluator': type(evaluator).__name__,
                           'estimatorParamMapsLength': 2}
        self.check_run_info(0, expected_params, {}, {})
        # check we have logging the avg and std metrics
        expected_metrics = {"accuracy": 1.0}
        self.check_run_info(1, {}, expected_metrics, {})
        expected_metrics = {"accuracy": 2.0}
        self.check_run_info(2, {}, expected_metrics, {})

        # check usage logging
        self.assert_num_logs(len(usage_records), 1)
        self.assert_tag(usage_records[0],
                        self.tag_definitions().TAG_ML_UTIL_TYPE(),
                        'mllibAutoTracking')

    def test_tvs_runs(self):
        self._test_training_runs(TrainValidationSplit)

    def test_cv_runs(self):
        self._test_training_runs(CrossValidator)

    def _test_training_runs(self, model_class):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        dataset = self.spark.createDataFrame(
            [(Vectors.dense([0.0]), 0.0),
             (Vectors.dense([0.4]), 1.0),
             (Vectors.dense([0.5]), 0.0),
             (Vectors.dense([0.6]), 1.0),
             (Vectors.dense([1.0]), 1.0)] * 10,
            ["features", "label"])
        spark = dataset.sql_ctx.sparkSession

        lr = LogisticRegression()
        grid = ParamGridBuilder().addGrid(lr.maxIter, [0, 1]).build()
        evaluator = MulticlassClassificationEvaluator(metricName="accuracy")
        if model_class is CrossValidator:
            model = model_class(estimator=lr, estimatorParamMaps=grid,
                                evaluator=evaluator, numFolds=2)
        else:
            model = model_class(estimator=lr, estimatorParamMaps=grid, evaluator=evaluator)

        # Set `util._mlfow` and `util._MlflowClient` to be None.
        # This mimics the case without MLflow
        util._mlflow = None
        util._MlflowClient = None
        spark.conf.set("spark.databricks.mlflow.trackMLlib.enabled", 'true')
        with warnings.catch_warnings(record=True) as warn:
            model.fit(dataset)
            wait_for_mlflow()
            self.assertEqual(len(warn), 1, "There should be one warning message without MLflow.")
            self.assertTrue("Can not find mlflow" in str(warn[-1].message),
                            """
                            Warning message should contain "Can not find mlflow" ({})
                            """.format(str(warn[-1].message)))

        self.assertEqual(mlflow_util.get_num_runs(),
                         0,
                         "There should be no MLflow logging without MLflow")

        # Test the case with MLflow, but not set the configs
        util._mlflow = mocked_mlflow
        util._MlflowClient = MockMlflowClient
        spark.conf.set("spark.databricks.mlflow.trackMLlib.enabled", 'false')
        with warnings.catch_warnings(record=True) as warn:
            model.fit(dataset)
            wait_for_mlflow()
            self.assertEqual(len(warn), 0,
                             "There should be no warning messages without spark config.")

        self.assertEqual(mlflow_util.get_num_runs(),
                         0,
                         "There should be no MLflow logging without configs")

        # Test the case with MLflow and the configs
        spark.conf.set("spark.databricks.mlflow.trackMLlib.enabled", 'true')
        with warnings.catch_warnings(record=True) as warn:
            model.fit(dataset)
            wait_for_mlflow()
            self.assertEqual(len(warn), 0, "There should be no warning messages.")
        self.assertEqual(mlflow_util.get_num_runs(), 3, "Not found MLflow runs. ({} for {})"
                         .format(mlflow_util.get_num_runs(), 3))

    def test_resolve_param_names(self):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        def compare_dicts(expected, resolved):
            self.assertEqual(
                len(expected), len(resolved),
                "Expected Param name dict had length {e}, but resolved had length {r}".format(
                    e=len(expected), r=len(resolved)))
            for p, expected_name in expected.items():
                self.assertEqual(
                    expected_name, resolved[p],
                    "Wrong Param name: Expected {e} but found {r}".format(
                        e=expected_name, r=resolved[p]))

        # Test: No duplicate Params
        lr1 = LogisticRegression()
        params1 = [lr1.maxIter, lr1.regParam]
        resolved1 = _MLflowInstrumentation._resolve_param_names(params1)
        expected1 = {
            lr1.maxIter: 'maxIter',
            lr1.regParam: 'regParam',
        }
        compare_dicts(expected1, resolved1)

        # Test: Duplicate Param names
        lr2 = LogisticRegression()
        params2 = [lr1.maxIter, lr1.regParam, lr2.maxIter]
        resolved2 = _MLflowInstrumentation._resolve_param_names(params2)
        expected2 = {
            lr1.maxIter: lr1.uid + '.maxIter',
            lr1.regParam: 'regParam',
            lr2.maxIter: lr2.uid + '.maxIter',
        }
        compare_dicts(expected2, resolved2)

    def test_async_call(self):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        async_task_queue = _AsynchronousTaskQueue()

        # test function with exceptions: like no mlflow servce
        def fun_with_error(run_uuid, tuning, metrics):
            raise RuntimeError('test failure')

        _MLflowInstrumentation.usage_logger = _MLflowUsageLogger()

        def check_async_call():
            with warnings.catch_warnings(record=True) as warn:
                async_task_queue.call(
                    fun=_MLflowInstrumentation._fun_call_catch_exception,
                    func=fun_with_error,
                    run_uuid=0,
                    tuning=0,
                    metrics=0)
                concurrent.futures.wait(async_task_queue.futures)
                self.assertEqual(len(warn), 1, "There should be one warning message "
                                               "when throwing errors in the async call.")
                self.assertTrue("RuntimeError" in str(warn[-1].message),
                                "Wrong warning message when function call with exception.")

        usage_records = self.track_usage(check_async_call)
        # check usage_log
        self.assert_num_logs(len(usage_records), 1)
        self.assert_tag(usage_records[0],
                        self.tag_definitions().TAG_ML_UTIL_TYPE(),
                        'mllibAutoTracking')
        self.assert_tag(usage_records[0],
                        self.tag_definitions().TAG_ERROR(),
                        "RuntimeError")
        self.assert_tag(usage_records[0],
                        self.tag_definitions().TAG_ERROR_MESSAGE(),
                        "test failure")

    def test_multi_runs(self):
        lr = LogisticRegression()
        grid = ParamGridBuilder().addGrid(lr.maxIter, [0, 1]).build()
        evaluator = MulticlassClassificationEvaluator(metricName="accuracy")
        cv = CrossValidator(estimator=lr, estimatorParamMaps=grid, evaluator=evaluator, numFolds=4)
        metrics = np.array([[1.0, 2.0], [1.0, 2.0], [1.0, 4.0], [1.0, 4.0]])

        mlflow_logger = _MLflowInstrumentation()

        with mocked_mlflow.start_run() as active_run:
            run_uuid1 = active_run.info.run_uuid
            mlflow_logger.log_crossvalidator(cv, metrics)
            wait_for_mlflow()
        with mocked_mlflow.start_run() as active_run:
            run_uuid2 = active_run.info.run_uuid
            mlflow_logger.log_crossvalidator(cv, metrics)
            wait_for_mlflow()
        num_params_1 = mlflow_util.get_num_params_for_run(run_uuid1)
        self.assertEqual(num_params_1,
                         6,
                         "Wrong number of params: Expected {} but got {}."
                         .format(num_params_1, 6))
        num_params_2 = mlflow_util.get_num_params_for_run(run_uuid2)
        self.assertEqual(num_params_2,
                         6,
                         "Wrong number of params: Expected {} but got {}."
                         .format(num_params_2, 6))


if __name__ == "__main__":
    from pyspark.databricks.tests.test_mllib_mlflow_logging import *

    try:
        import xmlrunner
        testRunner = xmlrunner.XMLTestRunner(output='target/test-reports')
    except ImportError:
        testRunner = None
    unittest.main(testRunner=testRunner, verbosity=2)
